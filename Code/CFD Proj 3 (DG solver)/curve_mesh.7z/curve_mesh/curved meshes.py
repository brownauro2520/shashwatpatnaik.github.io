# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 16:16:48 2023

@author: 15413
"""
import numpy as np


def readgri(fname):
    f = open(fname, 'r')
    Nn, Ne, dim = [int(s) for s in f.readline().split()]
    # read vertices
    V = list([[float(s) for s in f.readline().split()] for n in range(Nn)])
    # read boundaries
    NB = int(f.readline())
    B = []; Bname = []
    for i in range(NB):
        s = f.readline().split(); Nb = int(s[0]); Bname.append(s[2])
        Bi = list([[int(s) for s in f.readline().split()] for n in range(Nb)])
        B.append(Bi)
    # read elements
    Ne0 = 0; E = []
    while (Ne0 < Ne):
        s = f.readline().split(); ne = int(s[0])
        Ei = list([[int(s) for s in f.readline().split()] for n in range(ne)])
        E = Ei if (Ne0==0) else np.concatenate((E,Ei), axis=0)
        Ne0 += ne
    f.close()
    Mesh = {'V':V, 'E':E, 'B':B, 'Bname':Bname }
    return Mesh

def closest_coordinate(point, file_path): #finds the closest point
    closest_point = None
    closest_distance = float("inf")
    with open(file_path, "r") as f:
        for line in f:
            x, y = map(float, line.strip().split())
            distance = ((x - point[0])**2 + (y - point[1])**2)**0.5
            if distance < closest_distance:
                closest_distance = distance
                closest_point = (x, y)
    dif_x = list(closest_point)[0] - point[0]
    dif_y = list(closest_point)[1] - point[1]
    return closest_point, [dif_x,dif_y]

def curve_mesh(Mesh, B2E, fname):
    Nodec = Mesh['V']; E2N = Mesh['E']; B = Mesh['B']; Bname = Mesh['Bname']


    write_B = []
    for i in range(len(B)):
        line = [len(B[i]),len(B[i][0]),Bname[i]]
        write_B.append(line)
        for j in range(len(B[i])):
            write_B.append(B[i][j])
            

        
    BE = []
    BE_f = []
    BE2N = []
    new_E2N = E2N.copy()
    for i in range(len(B2E)):
        if B2E[i][2] != -1:
            BE.append(B2E[i][0])
            BE_f.append([B2E[i][0],B2E[i][1]])
            
    for i in range(len(E2N)):
        if i+1 in BE:
            new_E2N.remove(E2N[i])
            BE2N.append(E2N[i])

    # create new nodes of q = 3
    P1 = [0,0]
    P2 = [1/3,0]
    P3 = [2/3,0]
    P4 = [1,0]
    P5 = [0,1/3]
    P6 = [1/3,1/3]
    P7 = [2/3,1/3]
    P8 = [0,2/3]
    P9 = [1/3,2/3]
    P10 = [0,1]
    NP = [P1,P2,P3,P4,P5,P6,P7,P8,P9,P10]

    for i in range(len(BE2N)):
        p1 = Nodec[BE2N[i][0]-1]
        p2 = Nodec[BE2N[i][1]-1]
        p3 = Nodec[BE2N[i][2]-1]
        BE2N[i] = []
        dif = [0,0]
        for j in range(len(NP)):
            new_P = [0,0]
            new_N = NP[j]
            new_P[0] = p1[0]*(1-new_N[0]-new_N[1]) + p2[0]*new_N[0] + p3[0]*new_N[1]
            new_P[1] = p1[1]*(1-new_N[0]-new_N[1]) + p2[1]*new_N[0] + p3[1]*new_N[1]

            if new_P not in Nodec:
                Nodec.append(new_P)
                BE2N[i].append(len(Nodec))
            else:
                BE2N[i].append(int(Nodec.index(new_P)+1))
            
        if BE_f[i][1] == 1:
            Nodec[BE2N[i][1]-1],dif1 = closest_coordinate(Nodec[BE2N[i][1]-1], 'snap.txt')
            Nodec[BE2N[i][2]-1],dif2 = closest_coordinate(Nodec[BE2N[i][2]-1], 'snap.txt')
            dif[0] = (dif1[0] + dif2[0])/2*0.666
            dif[1] = (dif1[1] + dif2[1])/2*0.666
            Nodec[BE2N[i][5]-1][0] += dif[0]
            Nodec[BE2N[i][5]-1][1] += dif[1]
            
        elif BE_f[i][1] == 2:
            Nodec[BE2N[i][6]-1],dif1 = closest_coordinate(Nodec[BE2N[i][6]-1], 'snap.txt')
            Nodec[BE2N[i][8]-1],dif2 = closest_coordinate(Nodec[BE2N[i][8]-1], 'snap.txt')
            dif[0] = (dif1[0] + dif2[0])/2*0.666
            dif[1] = (dif1[1] + dif2[1])/2*0.666
            Nodec[BE2N[i][5]-1][0] += dif[0]
            Nodec[BE2N[i][5]-1][1] += dif[1]
            
        elif BE_f[i][1] == 3:
            Nodec[BE2N[i][4]-1],dif1 = closest_coordinate(Nodec[BE2N[i][4]-1], 'snap.txt')
            Nodec[BE2N[i][7]-1],dif2 = closest_coordinate(Nodec[BE2N[i][7]-1], 'snap.txt')
            dif[0] = (dif1[0] + dif2[0])/2*0.666
            dif[1] = (dif1[1] + dif2[1])/2*0.666
            Nodec[BE2N[i][5]-1][0] += dif[0]
            Nodec[BE2N[i][5]-1][1] += dif[1]
            



    # output new gri file
    with open(fname, "w") as f: 
        a = len(Nodec)
        b = len(E2N)
        f.write(f"{a} {b} 2\n")
        
        # Node coordinates
        for i in range(len(Nodec)):
            x, y = Nodec[i][0],Nodec[i][1]
            f.write("{:.15E} {:.15E}\n".format(x,y))
        
        # boundaries
        f.write("{}\n".format(len(B)))
        for i in range(len(write_B)):
            if len(write_B[i]) == 2:
                x, y = write_B[i][0],write_B[i][1]
                f.write(f"{x} {y}\n")
            if len(write_B[i]) == 3:
                x, y, z= write_B[i][0],write_B[i][1],write_B[i][2]
                f.write(f"{x} {y} {z}\n")
        
        
        # Node to Elements
        c = len(new_E2N)
        d = len(BE2N)
        f.write(f"{c} 1 TriLagrange\n")
        for i in range(len(new_E2N)):
            x, y, z = new_E2N[i][0],new_E2N[i][1],new_E2N[i][2]
            f.write("{} {} {}\n".format(x,y,z))
        
        f.write(f"{d} 3 TriLagrange\n")
        for i in range(len(BE2N)):
            n = []
            for j in range(len(BE2N[i])):
                n.append(BE2N[i][j])
            f.write("{} {} {} {} {} {} {} {} {} {}\n".format
                    (n[0],n[1],n[2],n[3],n[4],n[5],n[6],n[7],n[8],n[9]))
    


if __name__ == "__main__":
    
    # input mesh information(1.mesh.gri, 2.B2E)
    Mesh = readgri('C0.gri')
    B2E = [] 
    for line in open('B2E.txt', 'r'):
        K = line.strip().split()
        K[0] = int(float(K[0]))
        K[1] = int(float(K[1]))
        K[2] = int(float(K[2]))
        B2E.append(K)    
    # curve mesh    
    curve_mesh(Mesh, B2E, 'C0Q3.gri')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    